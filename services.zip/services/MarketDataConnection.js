// from websocket import create_connection
// import json

// ws = create_connection("wss://algogene.com/ws")

// msg = json.dumps({"msg_id":13, "user":"demo2", "api_key":"4WE4Qd010AqNZc9W701ZmR0U8I1d3mHl", "symbols":["BTCUSD","ETHUSD"], "broker":""})
// ws.send(str.encode(msg))

// while True:
//     res = ws.recv()
//     print('received ... ',res)